insert into student(rollNo, name, marks) values(21, 'Uday', 98);
insert into student(rollNo, name, marks) values(22, 'Manoj', 97);
insert into student(rollNo, name, marks) values(23, 'Hemanth', 96);

